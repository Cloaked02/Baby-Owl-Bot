﻿namespace NadekoBot.Modules.Utility.Common
{
    public class ConvertUnit
    {
        public string[] Triggers { get; set; }
        public string UnitType { get; set; }
        public decimal Modifier { get; set; }
    }
}
