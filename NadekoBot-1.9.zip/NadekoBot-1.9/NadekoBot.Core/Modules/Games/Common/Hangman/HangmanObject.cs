﻿namespace NadekoBot.Modules.Games.Common.Hangman
{
    public class HangmanObject
    {
        public string Word { get; set; }
        public string ImageUrl { get; set; }
    }
}
