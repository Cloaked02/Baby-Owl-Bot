﻿namespace NadekoBot.Core.Services.Impl
{
    public class SyncPreconditionService
    {
        
    }
}
