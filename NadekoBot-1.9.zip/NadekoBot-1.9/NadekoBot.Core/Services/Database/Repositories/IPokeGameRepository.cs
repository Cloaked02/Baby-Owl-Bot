﻿using NadekoBot.Core.Services.Database.Models;

namespace NadekoBot.Core.Services.Database.Repositories
{
    public interface IPokeGameRepository : IRepository<UserPokeTypes>
    {
        //List<UserPokeTypes> GetAllPokeTypes();
    }
}
