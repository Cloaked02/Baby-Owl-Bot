﻿namespace NadekoBot.Modules
{
    public static class NadekoModuleExtensions
    {
        
    }
}
