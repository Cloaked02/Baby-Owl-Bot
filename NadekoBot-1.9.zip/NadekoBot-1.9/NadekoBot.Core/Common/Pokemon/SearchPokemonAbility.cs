﻿namespace NadekoBot.Core.Common.Pokemon
{
    public class SearchPokemonAbility
    {
        public string Desc { get; set; }
        public string ShortDesc { get; set; }
        public string Name { get; set; }
        public float Rating { get; set; }
    }
}
